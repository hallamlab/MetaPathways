#ifndef DYNAMITEdymainHEADERFILE
#define DYNAMITEdymainHEADERFILE
#ifdef _cplusplus
extern "C" {
#endif





    /***************************************************/
    /* Callable functions                              */
    /* These are the functions you are expected to use */
    /***************************************************/



  /* Unplaced functions */
  /* There has been no indication of the use of these functions */


    /***************************************************/
    /* Internal functions                              */
    /* you are not expected to have to call these      */
    /***************************************************/

#ifdef _cplusplus
}
#endif

#endif
