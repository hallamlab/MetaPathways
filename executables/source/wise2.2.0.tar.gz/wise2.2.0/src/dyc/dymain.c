#ifdef _cplusplus
extern "C" {
#endif
#include "dymain.h"

# line 5 "dymain.c"

#ifdef _cplusplus
}
#endif
